package com.jwtauthentication.Model;
import lombok.Getter;

import lombok.Setter;

@Getter
@Setter

public class User {
    
    
    public String  userId;
    public String name;
    public String email;
    @Override
    public String toString() {
        return "User [userId=" + userId + ", name=" + name + ", email=" + email + "]";
    }

    public User() {
    }
    public User(String userId, String name, String email) {
        this.userId = userId;
        this.name = name;
        this.email = email;
    }
}
