package com.jwtauthentication.Services;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.stereotype.Service;

import com.jwtauthentication.Model.User;

@Service
public class UserService {
    
    List<User> store = new ArrayList<>();

    public UserService(){
        store.add(new User(UUID.randomUUID().toString(), "Aman Singh", "aman24@dev.com"));
        store.add(new User(UUID.randomUUID().toString(), "Aman", "aman24@gmail.com"));
    }

    public List<User>getUsers(){
        return this.store;
    }
}
